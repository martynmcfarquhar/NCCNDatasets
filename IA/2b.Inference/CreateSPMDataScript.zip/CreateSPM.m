
% Contrast weights
L = [1 -1 0 0];

% load design matrix
load('X.mat');
iXX = inv(X'*X);
df  = size(X,1) - size(X,2);

% Load parameter estimates
Header = niftiinfo('beta_0001.nii');
XDim = Header.ImageSize(1);
YDim = Header.ImageSize(2);
ZDim = Header.ImageSize(3);

Beta = zeros(4,XDim,YDim,ZDim);
Beta(1,:,:,:) = niftiread('beta_0001.nii');
Beta(2,:,:,:) = niftiread('beta_0002.nii'); 
Beta(3,:,:,:) = niftiread('beta_0003.nii'); 
Beta(4,:,:,:) = niftiread('beta_0004.nii'); 

% Load variance estimate
Variance = niftiread('ResMS.nii');

% Empty images for results
Contrast      = zeros(XDim,YDim,ZDim);
StandardError = zeros(XDim,YDim,ZDim);
TStatistic    = zeros(XDim,YDim,ZDim);

for x = 1:Header.ImageSize(1)
    for y = 1:Header.ImageSize(2)
        for z = 1:Header.ImageSize(3)
            
            Con = L * Beta(:,x,y,z);
            
            % Check we're inside the brain
            if (~isnan(Con))
                SE = sqrt(Variance(x,y,z) * (L * iXX * L'));
                T    = Con / SE;
                
                % Save values to images
                Contrast(x,y,z)      = Con;
                StandardError(x,y,z) = SE;
                TStatistic(x,y,z)    = T;         
            end
        end
    end
end

Header.Datatype              = 'double';
Header.BitsPerPixel          = 64;
Header.MultiplicativeScaling = 0;

niftiwrite(Contrast,      'Contrast.nii',       Header);
niftiwrite(StandardError, 'StandardError.nii',  Header);
niftiwrite(TStatistic,    'TStatistic.nii',     Header);
